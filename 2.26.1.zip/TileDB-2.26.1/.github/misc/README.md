This directory is called 'misc' instead of 'aux' because 'aux' is a reserved word on windows.
